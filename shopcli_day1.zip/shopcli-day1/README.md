# ShopCLI — Full-Stack E-Commerce Platform

A production-grade e-commerce application built over 30 days with:

- **Backend** — FastAPI · SQLAlchemy 2.0 · Alembic · Pydantic v2 · PostgreSQL · Redis
- **Frontend** — Next.js 14 (App Router) · TypeScript · Tailwind CSS · shadcn/ui
- **AI** — Claude API (product descriptions, customer chat) · pgvector (recommendations)
- **DevOps** — Docker Compose · GitHub Actions CI/CD · Prometheus · Grafana · Caddy

---

## Quick start (Day 1)

```bash
# 1. Clone and enter backend
cd backend

# 2. Create virtual environment
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -e ".[dev]"

# 4. Configure environment
cp .env.example .env
# Edit .env — at minimum set SECRET_KEY:
#   openssl rand -hex 32

# 5. Install pre-commit hooks
pre-commit install

# 6. Run dev server
make dev
# → http://localhost:8000/docs

# 7. Run tests
make test
```

---

## Project structure

```
shopcli/
├── backend/                  ← FastAPI API
│   ├── app/
│   │   ├── api/v1/           ← Route handlers (endpoints)
│   │   │   └── endpoints/    ← health.py, auth.py, products.py …
│   │   ├── core/             ← config.py, logging.py, security.py …
│   │   ├── models/           ← SQLAlchemy ORM models (Day 2)
│   │   ├── schemas/          ← Pydantic request/response schemas (Day 2)
│   │   ├── services/         ← Business logic layer (Day 5+)
│   │   ├── repositories/     ← DB query layer (Day 2+)
│   │   └── main.py           ← App factory
│   ├── alembic/              ← DB migrations (Day 2)
│   ├── tests/                ← pytest test suite
│   ├── scripts/              ← seed.py, generate_openapi.py
│   ├── .env.example
│   ├── pyproject.toml
│   └── Makefile
│
├── frontend/                 ← Next.js 14 app (Day 9+)
│   ├── app/                  ← App Router pages
│   ├── components/
│   ├── lib/
│   └── package.json
│
├── infra/                    ← Docker Compose, Caddy, Prometheus (Day 23+)
│   ├── docker-compose.yml
│   ├── Caddyfile
│   └── prometheus.yml
│
└── docs/                     ← Architecture decisions, API guides
    └── adr/                  ← Architecture Decision Records
```

---

## API endpoints (Day 1)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/health/live` | Liveness probe |
| GET | `/api/v1/health/ready` | Readiness probe |
| GET | `/api/v1/health` | Full health report |
| GET | `/api/v1/system/info` | App config info (dev only) |

Browse interactive docs: http://localhost:8000/docs

---

## Day-by-day progress

| Day | Topic | Status |
|-----|-------|--------|
| 1 | Project setup, FastAPI, health checks | ✅ |
| 2 | SQLAlchemy models + Alembic migrations | ⬜ |
| 3 | Auth — JWT + OAuth2 | ⬜ |
| … | … | … |

---

## Environment variables

See `.env.example` for the full list with descriptions.

The only **required** variable on Day 1 is `SECRET_KEY`.
Generate one with: `openssl rand -hex 32`

---

## Contributing

1. Branch from `main` — `git checkout -b day-2/database`
2. Write code + tests
3. `make check` must pass (lint + types)
4. `make test` must pass (≥80% coverage)
5. Open PR — CI runs automatically
