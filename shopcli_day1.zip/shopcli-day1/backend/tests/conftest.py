"""
tests/conftest.py
Shared pytest configuration and fixtures.
"""
import pytest


# Tell pytest-asyncio to treat all async tests as asyncio automatically
# (set in pyproject.toml too: asyncio_mode = "auto")
