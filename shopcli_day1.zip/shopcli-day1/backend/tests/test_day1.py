"""
tests/test_day1.py
Day 1 test suite — config, health endpoints, system info.

Run:  pytest tests/test_day1.py -v
"""
import pytest
from httpx import ASGITransport, AsyncClient


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def app():
    """Create a fresh FastAPI app instance for each test."""
    from app.main import create_app
    return create_app()


@pytest.fixture
async def client(app):
    """Async test client — no real network calls."""
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as ac:
        yield ac


# ── Settings tests ────────────────────────────────────────────────────────────

class TestSettings:
    def test_settings_load(self):
        from app.core.config import get_settings
        s = get_settings()
        assert s.APP_NAME == "ShopCLI"
        assert s.APP_VERSION

    def test_cors_origins_parsed(self):
        from app.core.config import get_settings
        s = get_settings()
        origins = s.cors_origins
        assert isinstance(origins, list)
        assert len(origins) >= 1
        assert all(o.startswith("http") for o in origins)

    def test_is_sqlite_dev(self):
        from app.core.config import get_settings
        s = get_settings()
        # In dev the default DATABASE_URL uses sqlite
        assert s.is_sqlite

    def test_is_not_production(self):
        from app.core.config import get_settings
        s = get_settings()
        assert not s.is_production

    def test_token_expire_seconds(self):
        from app.core.config import get_settings
        s = get_settings()
        assert s.access_token_expire_seconds == s.ACCESS_TOKEN_EXPIRE_MINUTES * 60
        assert s.refresh_token_expire_seconds == s.REFRESH_TOKEN_EXPIRE_DAYS * 86400


# ── Health endpoint tests ──────────────────────────────────────────────────────

class TestHealthEndpoints:
    async def test_liveness_returns_200(self, client):
        r = await client.get("/api/v1/health/live")
        assert r.status_code == 200
        assert r.json() == {"status": "ok"}

    async def test_readiness_returns_200(self, client):
        r = await client.get("/api/v1/health/ready")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ready"
        assert "checks" in body
        assert body["checks"]["app"] == "ok"

    async def test_health_report_shape(self, client):
        r = await client.get("/api/v1/health")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "healthy"
        assert "uptime_seconds" in body
        assert "timestamp" in body
        assert isinstance(body["checks"], dict)

    async def test_health_report_version(self, client):
        from app.core.config import get_settings
        s = get_settings()
        r = await client.get("/api/v1/health")
        assert r.json()["version"] == s.APP_VERSION
        assert r.json()["app"] == s.APP_NAME

    async def test_request_id_header_present(self, client):
        r = await client.get("/api/v1/health/live")
        assert "x-request-id" in r.headers

    async def test_cors_header_present(self, client):
        r = await client.get(
            "/api/v1/health/live",
            headers={"Origin": "http://localhost:3000"},
        )
        assert "access-control-allow-origin" in r.headers


# ── System info tests ─────────────────────────────────────────────────────────

class TestSystemInfo:
    async def test_system_info_in_dev(self, client):
        r = await client.get("/api/v1/system/info")
        assert r.status_code == 200
        body = r.json()
        assert "python_version" in body
        assert "database_engine" in body
        assert "features" in body
        assert isinstance(body["cors_origins"], list)

    async def test_system_info_shows_sqlite(self, client):
        r = await client.get("/api/v1/system/info")
        assert "SQLite" in r.json()["database_engine"]

    async def test_system_info_features_dict(self, client):
        r = await client.get("/api/v1/system/info")
        features = r.json()["features"]
        assert "redis" in features
        assert "s3" in features
        assert "email" in features
        # All False in dev with empty .env values
        assert isinstance(features["redis"], bool)


# ── Middleware / error handler tests ──────────────────────────────────────────

class TestMiddleware:
    async def test_404_returns_json(self, client):
        r = await client.get("/api/v1/does-not-exist")
        assert r.status_code == 404

    async def test_validation_error_format(self, client):
        """POST to health with bad body triggers validation error handler."""
        r = await client.post("/api/v1/health", json={"bad": "data"})
        # POST not allowed → 405, just checking we get JSON not HTML
        assert r.headers["content-type"].startswith("application/json")
