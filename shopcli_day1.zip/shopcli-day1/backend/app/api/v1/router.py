"""
app/api/v1/router.py
Central router that wires every sub-router together.
On Day 1 we only have the health & system routes.
Future days add: auth, products, cart, orders, admin.
"""
from fastapi import APIRouter

from app.api.v1.endpoints import health, system

api_router = APIRouter()

# ── Core (Day 1) ──────────────────────────────────────────────────────────────
api_router.include_router(health.router, prefix="/health", tags=["health"])
api_router.include_router(system.router, prefix="/system", tags=["system"])

# ── Day 3+  (uncomment as you build them) ────────────────────────────────────
# from app.api.v1.endpoints import auth
# api_router.include_router(auth.router, prefix="/auth", tags=["auth"])

# from app.api.v1.endpoints import products
# api_router.include_router(products.router, prefix="/products", tags=["products"])

# from app.api.v1.endpoints import cart
# api_router.include_router(cart.router, prefix="/cart", tags=["cart"])

# from app.api.v1.endpoints import orders
# api_router.include_router(orders.router, prefix="/orders", tags=["orders"])

# from app.api.v1.endpoints import admin
# api_router.include_router(admin.router, prefix="/admin", tags=["admin"])
