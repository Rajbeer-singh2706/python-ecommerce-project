"""
app/api/v1/endpoints/system.py

System information endpoint — useful in development to verify
env vars, build info, and feature flags are loaded correctly.
Disabled in production (see main.py docs_url=None guard pattern).
"""
import platform
import sys

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from app.core.config import Settings, get_settings

router = APIRouter()


class SystemInfo(BaseModel):
    app_name: str
    version: str
    environment: str
    debug: bool
    python_version: str
    platform: str
    database_engine: str
    cors_origins: list[str]
    features: dict[str, bool]


def _get_db_engine(url: str) -> str:
    """Extract human-readable engine name from DATABASE_URL."""
    if "sqlite" in url:
        return "SQLite (dev)"
    if "postgresql" in url or "asyncpg" in url:
        return "PostgreSQL"
    if "mysql" in url:
        return "MySQL"
    return "Unknown"


@router.get(
    "/info",
    summary="System information",
    response_model=SystemInfo,
    description="Returns app configuration. **Only available in non-production.**",
)
async def system_info(
    settings: Settings = Depends(get_settings),
) -> SystemInfo:
    if settings.is_production:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Not available in production.",
        )

    return SystemInfo(
        app_name=settings.APP_NAME,
        version=settings.APP_VERSION,
        environment=settings.APP_ENV,
        debug=settings.DEBUG,
        python_version=sys.version.split()[0],
        platform=platform.system(),
        database_engine=_get_db_engine(settings.DATABASE_URL),
        cors_origins=settings.cors_origins,
        features={
            "redis": bool(settings.REDIS_URL),
            "s3": bool(settings.S3_BUCKET and settings.AWS_ACCESS_KEY_ID),
            "email": bool(settings.SMTP_HOST and settings.SMTP_USER),
        },
    )
