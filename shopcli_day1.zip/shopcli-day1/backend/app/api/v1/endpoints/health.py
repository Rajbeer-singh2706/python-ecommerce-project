"""
app/api/v1/endpoints/health.py

Three tiers of health checks — a common production pattern:
  GET /api/v1/health/live   → liveness probe  (is the process alive?)
  GET /api/v1/health/ready  → readiness probe (can we serve traffic?)
  GET /api/v1/health        → full status     (human-readable detail)

Kubernetes / Docker use /live and /ready.
Load balancers use /ready before routing traffic.
"""
import time
from datetime import datetime, timezone

from fastapi import APIRouter, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from app.core.config import get_settings
from app.core.logging import get_logger

router = APIRouter()
settings = get_settings()
logger = get_logger(__name__)

# Track server start time for uptime reporting
_START_TIME = time.monotonic()


class HealthStatus(BaseModel):
    status: str
    app: str
    version: str
    environment: str
    uptime_seconds: float
    timestamp: str
    checks: dict[str, str]


@router.get(
    "/live",
    summary="Liveness probe",
    description="Returns 200 if the process is running. Used by Kubernetes.",
    status_code=status.HTTP_200_OK,
)
async def liveness() -> dict[str, str]:
    """Minimal check — process is alive."""
    return {"status": "ok"}


@router.get(
    "/ready",
    summary="Readiness probe",
    description="Returns 200 when the app is ready to serve traffic.",
    status_code=status.HTTP_200_OK,
)
async def readiness() -> JSONResponse:
    """
    Check all critical dependencies.
    On Day 1: only the app itself.
    Day 2+: add DB ping.
    Day 18+: add Redis ping.
    """
    checks: dict[str, str] = {"app": "ok"}

    # Day 2+ — uncomment when DB is set up:
    # try:
    #     await db_check()
    #     checks["database"] = "ok"
    # except Exception as e:
    #     checks["database"] = f"error: {e}"

    all_ok = all(v == "ok" for v in checks.values())
    code = status.HTTP_200_OK if all_ok else status.HTTP_503_SERVICE_UNAVAILABLE

    return JSONResponse(
        status_code=code,
        content={"status": "ready" if all_ok else "degraded", "checks": checks},
    )


@router.get(
    "",
    summary="Full health report",
    response_model=HealthStatus,
)
async def health_report() -> HealthStatus:
    """Detailed health status — useful for ops dashboards."""
    checks: dict[str, str] = {"app": "ok"}

    return HealthStatus(
        status="healthy",
        app=settings.APP_NAME,
        version=settings.APP_VERSION,
        environment=settings.APP_ENV,
        uptime_seconds=round(time.monotonic() - _START_TIME, 2),
        timestamp=datetime.now(timezone.utc).isoformat(),
        checks=checks,
    )
