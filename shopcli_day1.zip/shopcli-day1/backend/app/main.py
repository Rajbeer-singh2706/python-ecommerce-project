"""
app/main.py
FastAPI application factory.

The create_app() pattern (instead of a bare module-level `app = FastAPI()`)
makes the app easy to test — each test gets a fresh instance.
"""
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import get_settings
from app.core.logging import get_logger, setup_logging

settings = get_settings()
logger = get_logger(__name__)


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Code before `yield` runs on startup.
    Code after `yield`  runs on shutdown.
    Replace prints with real setup as you add DB / Redis / etc. on later days.
    """
    setup_logging()
    logger.info(
        "Starting %s v%s [%s]",
        settings.APP_NAME,
        settings.APP_VERSION,
        settings.APP_ENV,
    )

    # Day 2+: await init_db() goes here
    # Day 18+: await init_redis() goes here

    yield

    logger.info("Shutting down %s", settings.APP_NAME)
    # Day 2+: await close_db() goes here


# ── App factory ───────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        description=(
            "Production-grade e-commerce REST API.\n\n"
            "Built with FastAPI · SQLAlchemy 2.0 · Pydantic v2 · Alembic."
        ),
        docs_url="/docs" if not settings.is_production else None,
        redoc_url="/redoc" if not settings.is_production else None,
        openapi_url="/openapi.json" if not settings.is_production else None,
        lifespan=lifespan,
    )

    _register_middleware(app)
    _register_exception_handlers(app)
    _register_routers(app)

    return app


# ── Middleware ────────────────────────────────────────────────────────────────

def _register_middleware(app: FastAPI) -> None:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Add request-id to every response for tracing
    @app.middleware("http")
    async def add_request_id(request: Request, call_next):  # type: ignore[no-untyped-def]
        import uuid
        request_id = str(uuid.uuid4())
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response

    # Log every request in dev
    if settings.DEBUG:
        @app.middleware("http")
        async def log_requests(request: Request, call_next):  # type: ignore[no-untyped-def]
            logger.debug("%s %s", request.method, request.url.path)
            response = await call_next(request)
            logger.debug("→ %s", response.status_code)
            return response


# ── Exception handlers ────────────────────────────────────────────────────────

def _register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        """Return RFC 7807-style errors for validation failures."""
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={
                "type": "validation_error",
                "title": "Request validation failed",
                "detail": exc.errors(),
            },
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        logger.exception("Unhandled exception on %s %s", request.method, request.url)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "type": "internal_error",
                "title": "An unexpected error occurred",
                "detail": str(exc) if settings.DEBUG else "Contact support.",
            },
        )


# ── Routers ───────────────────────────────────────────────────────────────────

def _register_routers(app: FastAPI) -> None:
    from app.api.v1.router import api_router

    app.include_router(api_router, prefix="/api/v1")


# ── Module-level app instance (used by uvicorn) ───────────────────────────────
app = create_app()
