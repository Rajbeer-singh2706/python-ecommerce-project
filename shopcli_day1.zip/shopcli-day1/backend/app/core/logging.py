"""
app/core/logging.py
Structured logging setup.
  - Development: human-readable coloured output via Rich
  - Production:  JSON lines (one JSON object per line) for log aggregators
"""
import logging
import sys
from typing import Any

from app.core.config import get_settings

settings = get_settings()


class _RichHandler(logging.StreamHandler):
    """Minimal colour handler that works without the 'rich' package installed."""

    COLOURS = {
        "DEBUG": "\033[36m",    # cyan
        "INFO": "\033[32m",     # green
        "WARNING": "\033[33m",  # yellow
        "ERROR": "\033[31m",    # red
        "CRITICAL": "\033[35m", # magenta
    }
    RESET = "\033[0m"

    def emit(self, record: logging.LogRecord) -> None:
        colour = self.COLOURS.get(record.levelname, "")
        msg = self.format(record)
        print(f"{colour}[{record.levelname}]{self.RESET} {msg}", file=sys.stderr)


class _JSONFormatter(logging.Formatter):
    """Outputs each log record as a single JSON line."""

    def format(self, record: logging.LogRecord) -> str:
        import json
        from datetime import datetime, timezone

        payload: dict[str, Any] = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        # Merge any extra fields passed via logger.info("...", extra={...})
        for key, value in record.__dict__.items():
            if key not in {
                "args", "created", "exc_info", "exc_text", "filename",
                "funcName", "id", "levelname", "levelno", "lineno",
                "message", "module", "msecs", "msg", "name", "pathname",
                "process", "processName", "relativeCreated", "stack_info",
                "taskName", "thread", "threadName",
            }:
                payload[key] = value
        return json.dumps(payload, default=str)


def setup_logging() -> None:
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if settings.DEBUG else logging.INFO)

    # Remove any existing handlers (uvicorn adds its own)
    root.handlers.clear()

    if settings.is_production:
        handler: logging.Handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(_JSONFormatter())
    else:
        handler = _RichHandler()
        handler.setFormatter(
            logging.Formatter("%(name)s | %(message)s")
        )

    root.addHandler(handler)

    # Quieten noisy third-party loggers
    for noisy in ("uvicorn.access", "sqlalchemy.engine", "httpx"):
        logging.getLogger(noisy).setLevel(
            logging.WARNING if not settings.DEBUG else logging.INFO
        )


def get_logger(name: str) -> logging.Logger:
    """Convenience wrapper — use instead of logging.getLogger() everywhere."""
    return logging.getLogger(name)
